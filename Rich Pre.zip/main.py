import rpc
import time

print("Demo for python-discord-rpc")
client_id = '466572107455922176' #Your application's client ID as a string. (This isn't a real client ID)
rpc_obj = rpc.DiscordIpcClient.for_platform(client_id) #Send the client ID to the rpc module
print("RPC connection successful.")

time.sleep(5)
start_time = time.time()
while True:
    activity = {
            "state": "은혼 보는중",
            "details": "銀魂見る中...",
            "timestamps": {
                "start": start_time
            },
            "assets": {
                "small_text": "Gin JJAN",
                "small_image": "lg",
                "large_text": "Gintama",
                "large_image": "sm"
            }
        }
    rpc_obj.set_activity(activity)
    time.sleep(30)